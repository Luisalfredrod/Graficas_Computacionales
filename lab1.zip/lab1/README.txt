README.txt
 *  TC3022 - Homework 1: Learning Three.js
====================================================



1. What is your name?



<Luis Alfredo Rodriguez Santos>


2. What browser and operating system did you test your program with?

<Opera-Windows 10 x64>






3. Approximately how many hours did you spend working on this assignment?


<1hour15minutes>




4. Describe any problems you encountered in this assignment.
 * What was hard, or what should we warn students about in the future?
 * How can I make this assignment better?
 
<It was an easy assignment you could maybe include less code on the source
code because for some of the functions you dont need to reed the chapter 
necessarly.>






5. List any other comments (about the assignment or your submission)
 * here. Feel free to provide any feedback on what you learned from
 * doing the assignment, whether you enjoyed doing it, etc.
 
<Im looking foward to the next assignment i enjoyed this excersise.>
