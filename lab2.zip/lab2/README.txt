/**********************************************************************
 *  README.txt
 *  TC3022 - Homework 2: Rainbow circle
 **********************************************************************/

/**********************************************************************
* What is your name?
***********************************************************************/
Luis Alfredo Rodriguez Santos

/**********************************************************************
* What browser and operating system did you test your program with?
***********************************************************************/
<Opera-Windows 10 x64>

/**********************************************************************
* Did you refer to the hint file to complete the assignment, or did
* you do it entirely from the start file?
***********************************************************************/
It was very dificult to follow, could not do it without the chapter from
the book.

/**********************************************************************
* Approximately how many hours did you spend working on this assignment?
***********************************************************************/
3 hours.

/**********************************************************************
 * Describe any problems you encountered in this assignment.
 * What was hard, or what should we warn students about in the future?
 * How can I make this assignment better?
 **********************************************************************/
I needed a writen tutorial or something because it was hard to follow
the instructions.

/**********************************************************************
 * List any other comments (about the assignment or your submission)
 * here. Feel free to provide any feedback on what you learned from
 * doing the assignment, whether you enjoyed doing it, etc.
 **********************************************************************/

